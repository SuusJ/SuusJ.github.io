simpleGauge.js
===========

Introduction
----------------

Just a simple gauge using pure CSS3. The jQuery only comes into effect for managing dynamic colors, grabbing data values and making it easier to implement multiple gauges.

What it looks like?
----------------

![Example](/example/example.png?raw=true)

License
----------------

Released under GNU GPL ( [gnu.org](http://www.gnu.org/licenses/) )
